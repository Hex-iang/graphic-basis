// see the corresponding C++ file to see what they do
// void save_image();
void histogram_normalization();
void save_image(const string imagefullpath = "scene.bmp");
